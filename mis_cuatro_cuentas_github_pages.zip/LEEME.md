# Mis cuatro cuentas — Panel de almacenamiento

Aplicación web estática para Android (Chrome). Consulta `storageQuota` de la API oficial de Google Drive mediante OAuth 2.0. No incluye servidor ni contraseñas.

## Paso 1 — Publicar en GitHub Pages desde el móvil

1. Entra en https://github.com y crea un repositorio **público**, por ejemplo `mis-cuatro-cuentas`. No añadas tus direcciones de correo ni claves al repositorio.
2. En el repositorio, pulsa **Add file → Upload files** y sube `index.html` (no el ZIP). Confirma el cambio en `main`. Si el menú no aparece en el móvil, activa «Sitio para ordenadores» en Chrome.
3. En **Settings → Pages**, elige **Deploy from a branch**, rama `main` y carpeta `/(root)`; guarda.
4. Espera a que GitHub Pages publique la dirección `https://TU_USUARIO.github.io/mis-cuatro-cuentas/`.

## Paso 2 — Autorizar Google

1. En https://console.cloud.google.com crea un proyecto.
2. Habilita **Google Drive API**.
3. En **Google Auth Platform** configura la marca/pantalla de consentimiento, público **External** y el alcance `https://www.googleapis.com/auth/drive.metadata.readonly`. En modo de prueba, añade tus cuatro correos como usuarios de prueba.
4. En **Clients**, crea un cliente OAuth de tipo **Web application**.
5. En **Authorized JavaScript origins** añade `https://TU_USUARIO.github.io` (sin ruta ni barra final). No necesitas una URI de redirección para este flujo de token emergente.
6. Copia el **Client ID** (no el Client Secret) y pégalo en el panel. Guarda.
7. Introduce tus cuatro correos en el panel y pulsa «Guardar direcciones». Conecta cada cuenta con su propia sesión de Google.

## Notas

- Los correos y el ID de cliente se guardan en `localStorage` del navegador, no en GitHub. Los tokens solo viven en la memoria de la pestaña.
- Las sesiones pueden caducar y requerir reconexión. No se consulta Google Fotos por separado: se utiliza la cuota global informada por Drive.
- La cuota puede tardar en reflejar la limpieza de la Papelera y puede diferir temporalmente de Google One.
- No publiques secretos, contraseñas ni tokens en GitHub.
- Google puede mostrar advertencias de app no verificada mientras esté en pruebas. Comprueba siempre que el proyecto sea el tuyo y que los permisos solicitados sean los previstos.
